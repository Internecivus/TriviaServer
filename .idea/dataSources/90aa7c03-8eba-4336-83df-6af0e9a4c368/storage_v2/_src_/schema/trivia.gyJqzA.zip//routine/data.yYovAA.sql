create procedure data()
  insert into user(name, password, access_level) values ("viktor", "lenz", 3);

